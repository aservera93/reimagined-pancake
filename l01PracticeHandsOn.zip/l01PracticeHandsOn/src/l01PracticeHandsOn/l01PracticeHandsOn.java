package l01PracticeHandsOn;

public class l01PracticeHandsOn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
